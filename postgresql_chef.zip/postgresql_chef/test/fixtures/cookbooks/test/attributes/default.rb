default['br_yum']['repo_url'] = 'https://rhrepo.broadridge.net/rh7-latest'
default['br_tss_dba_postgresql_app']['postgres'].tap do |param|
  param['postgres_home_dir'] = '/usr/pgsql-12/bin'
  param['postgres_data_dir'] = '/var/lib/pgsql/12/data'
  param['major_version'] = '12'
end
