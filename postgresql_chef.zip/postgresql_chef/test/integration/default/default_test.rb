# Encoding: UTF-8

# Inspec test for recipe br_tss_dba_postgresql_app::default

# The Inspec reference, with examples and extensive documentation, can be
# found at http://inspec.io/docs/reference/resources/

describe user('postgres') do
  it { should exist }
end

describe group('dba') do
  it { should exist }
end

describe file('/usr/pgsql-12/bin/psql') do
  it { should exist }
  it { should be_executable }
end

describe command('/usr/pgsql-12/bin/psql').exist? do
  it { should eq true }
end
