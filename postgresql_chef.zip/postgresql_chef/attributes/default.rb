default['br_tss_dba_postgresql_app']['postgres'].tap do |param|
  param['source_url'] = ['https://nexus.devops.broadridge.net/repository/DBA-TSS-TEST-DEV/pgdg-redhat-repo-latest.noarch.rpm', 'https://nexus.devops.broadridge.net/repository/DBA-TSS-TEST-DEV/postgresql12-12.3-1PGDG.rhel7.x86_64.rpm', 'https://nexus.devops.broadridge.net/repository/DBA-TSS-TEST-DEV/postgresql12-contrib-12.3-1PGDG.rhel7.x86_64.rpm', 'https://nexus.devops.broadridge.net/repository/DBA-TSS-TEST-DEV/postgresql12-server-12.3-1PGDG.rhel7.x86_64.rpm']
  param['postgres_user'] = 'postgres'
  param['postgres_group'] = 'dba'
  param['postgres_home_dir'] = nil
  param['postgres_data_dir'] = nil
  param['major_version'] = nil
end
