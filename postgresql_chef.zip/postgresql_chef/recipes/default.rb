# Encoding: UTF-8
#
# Cookbook:: br_tss_dba_postgresql_app
# Recipe:: default
#
# Copyright:: 2020, Broadridge, All Rights Reserved.
# Exporting Variables
postgres = node['br_tss_dba_postgresql_app']['postgres']

# ####################### User Creation ##########################################################
group postgres['postgres_group'] do
  gid 4059
  action :create
end

user postgres['postgres_user'] do
  gid 4059
  comment 'A postgressoft user'
  shell '/bin/bash'
  manage_home true
  system true
  action [:create, :lock]
end

# ###############postgres user bash profile file ###################
template '/home/postgres/.bash_profile' do
  source 'postgres_bash.erb'
  owner postgres['postgres_user']
  group postgres['postgres_group']
  mode '0750'
  variables postgres_data_dir: postgres['postgres_data_dir'],
            postgres_install_dir: postgres['postgres_home_dir']
  notifies :run, 'execute[Postgres DB Initialization]', :delayed
  action :create
end

# ###############Download RPMs ###################
postgres['source_url'].each do |url|
  package_rpm_name = ::File.basename(url)
  package_rpm = remote_file url do
    source url
    path ::File.join(Chef::Config[:file_cache_path], package_rpm_name)
    mode '0644'
    notifies :upgrade, "package[#{package_rpm_name}]", :immediately
  end

  package package_rpm_name do
    source package_rpm.path
    action :nothing
  end
end

# ########### Postgres Initialization ###########
execute 'Postgres DB Initialization' do
  command <<-CMD
  #{postgres['postgres_home_dir']}/postgresql-*-setup initdb
  chown -R postgres:dba #{postgres['postgres_home_dir']}
  chown -R postgres:dba #{postgres['postgres_data_dir']}
  CMD
  notifies :restart, "service[postgresql-#{postgres['major_version']}]", :delayed
  action :nothing
end

service "postgresql-#{postgres['major_version']}" do
  action [:start, :enable]
  ignore_failure true
end

# ########### Enable cron ###########
# cron_access postgres['postgres_user'] do
#  action :allow
# end
