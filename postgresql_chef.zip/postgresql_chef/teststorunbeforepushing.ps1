#Run tests before committing
"Foodcritic"
"-------------"
chef exec foodcritic .
""
"Cookstyle"
"-------------"
chef exec cookstyle
""
"Rspec"
"-------------"
chef exec rspec -c

"Broadridge Validation"
"-------------"
chef exec ruby .br_chef_checker.rb
