# br_tss_dba_postgresql_app

[![pipeline status](https://git.devops.broadridge.net/DBA-TSS/Chef-Cookbooks/br_tss_dba_postgresql_app/badges/master/pipeline.svg)](https://git.devops.broadridge.net/DBA-TSS/Chef-Cookbooks/br_tss_dba_postgresql_app/commits/master)

## Overview

This cookbook facilitates the process of installing Postgres Database ver-11 and future editions, for Linux platforms. It is written to support variations of server builds across Broadridge.

Note: This cookbook only installs Postgres Binaries and creates default Sample and Template databases.

## Platforms

`RHEL 7+` (and its derivatives)

## Prerequisites and Dependencies

Minimum server level requirements
•Linux server with RHEL 7 (or higher)
•RAM: 4GB (recommend 8GB or more)
•Storage: A separate device and volume group is required for the Postgres Home with a minimum recommended size of 20G.

## Cookbook Dependencies
•The `br_yum` cookbook is required for installing OS packages.
•A local volume and mount point must exist for the Postgres Home. In this cookbook /postgresql is created with the `lvm` cookbook.

## Usage

To use this cookbook;

1) Place a dependency in your `metadata.rb`

            depends 'br_tss_dba_postgresql_app'

2) Ensure all attributes (described below with example values) are defined in your local attributes default.rb file.

3) Add an include line in your recipe to call this cookbook.

            include_recipe br_tss_dba_postgresql_app::default

### Required Attributes

Below are descriptions and example values for these parameters.

            default['br_tss_dba_postgresql_app']['postgres']['postgres_home_dir'] = '/usr/pgsql-11/bin'

Postgres Data directory: The Postgres data directory location (Stores all data related files)

            default['br_tss_dba_postgresql_app']['postgres']['postgres_data_dir'] = '/var/lib/pgsql/11/data'


## Other parameters


Source URL: Source location of software run file(i.e. Nexus).

            default['br_tss_dba_postgresql_app']['postgres']['source_url'] = ['https://nexus.devops.broadridge.net/repository/3rdParty_RAW/postgres/pgdg-redhat-repo-latest.noarch.rpm',
                                       'https://nexus.devops.broadridge.net/repository/3rdParty_RAW/postgres/postgresql11-11.5-1PGDG.rhel7.x86_64.rpm',
                                       'https://nexus.devops.broadridge.net/repository/3rdParty_RAW/postgres/postgresql11-libs-11.5-1PGDG.rhel7.x86_64.rpm',
                                       'https://nexus.devops.broadridge.net/repository/3rdParty_RAW/postgres/postgresql11-server-11.5-1PGDG.rhel7.x86_64.rpm']
