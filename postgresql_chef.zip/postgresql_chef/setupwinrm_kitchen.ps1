<powershell>
$OSVersion = (get-itemproperty -Path "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion" -Name ProductName).ProductName
If($OSVersion.contains('2016'))
{
      $logfile='C:\ProgramData\Amazon\EC2-Windows\Launch\Log\kitchen-ec2.log'
# EC2Launch doesn't init extra disks by default
C:\ProgramData\Amazon\EC2-Windows\Launch\Scripts\InitializeDisks.ps1
}
Else
{
$logfile='C:\Program Files\Amazon\Ec2ConfigService\Logs\kitchen-ec2.log'
}
# Allow script execution
Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Force
#PS Remoting and & winrm.cmd basic config
$enableArgs=@{Force=$true}
$command=Get-Command Enable-PSRemoting
if($command.Parameters.Keys -contains "skipnetworkprofilecheck"){
  $enableArgs.skipnetworkprofilecheck=$true
}
Enable-PSRemoting @enableArgs
& winrm.cmd set winrm/config '@{MaxTimeoutms="1800000"}' >> $logfile
& winrm.cmd set winrm/config/winrs '@{MaxMemoryPerShellMB="1024"}' >> $logfile
& winrm.cmd set winrm/config/winrs '@{MaxShellsPerUser="50"}' >> $logfile
& winrm.cmd set winrm/config/winrs '@{MaxMemoryPerShellMB="1024"}' >> $logfile
#Firewall Config
& netsh advfirewall firewall set rule name="Windows Remote Management (HTTP-In)" profile=public protocol=tcp localport=5985 remoteip=localsubnet new remoteip=any  >> $logfile
Set-ItemProperty -Name LocalAccountTokenFilterPolicy -Path HKLM:\software\Microsoft\Windows\CurrentVersion\Policies\system -Value 1

New-Item -Path HKLM:\SOFTWARE\WOW6432Node\Policies\Microsoft\Windows\WinRM\Service -Name WinRS
Set-ItemProperty -Path HKLM:\SOFTWARE\WOW6432Node\Policies\Microsoft\Windows\WinRM\Service\WinRS -Name AllowRemoteShellAccess -Value 1
New-Item -Path HKLM:\SOFTWARE\Policies\Microsoft\Windows\WinRM\Service -Name WinRS
Set-ItemProperty -Path HKLM:\SOFTWARE\Policies\Microsoft\Windows\WinRM\Service\WinRS -Name AllowRemoteShellAccess -Value 1
Remove-ItemProperty -Path HKLM:\SOFTWARE\Policies\Microsoft\Windows\WinRM\Service -Name AllowAutoConfig
Remove-ItemProperty -Path HKLM:\SOFTWARE\WOW6432Node\Policies\Microsoft\Windows\WinRM\Service -Name AllowAutoConfig
Set-ItemProperty -Path HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System -Name EnableLUA -Value 0
Set-ItemProperty -Path HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System -Name FilterAdministratorToken -Value 0

Function Set-SessionConfig
{
 Param( [string]$user )
 $account = New-Object Security.Principal.NTAccount $user
 $sid = $account.Translate([Security.Principal.SecurityIdentifier]).Value

 $config = Get-PSSessionConfiguration -Name "Microsoft.PowerShell"
 $existingSDDL = $Config.SecurityDescriptorSDDL

 $isContainer = $false
 $isDS = $false
 $SecurityDescriptor = New-Object -TypeName Security.AccessControl.CommonSecurityDescriptor -ArgumentList $isContainer,$isDS, $existingSDDL
 $accessType = "Allow"
 $accessMask = 268435456
 $inheritanceFlags = "none"
 $propagationFlags = "none"
 $SecurityDescriptor.DiscretionaryAcl.AddAccess($accessType,$sid,$accessMask,$inheritanceFlags,$propagationFlags)
 $SecurityDescriptor.GetSddlForm("All")
} #end Set-SessionConfig

# *** Entry Point to script ***

$user = "Administrator"
$newSDDL = Set-SessionConfig -user $user
Get-PSSessionConfiguration |
ForEach-Object {
 Set-PSSessionConfiguration -name $_.name -SecurityDescriptorSddl $newSDDL -force }

Restart-Service -Name WinRM
</powershell>
<persist>true</persist>
